// inside your click handler
lightbox.classList.add('visible');
// to close
lightbox.classList.remove('visible');

lightbox.addEventListener('click', (e) => {
  if (e.target !== img) {
    lightbox.style.opacity = '0';
    lightbox.style.pointerEvents = 'none';
  }
});


document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && lightbox.style.opacity === '1') {
    lightbox.style.opacity = '0';
    lightbox.style.pointerEvents = 'none';
  }
});

document.addEventListener('DOMContentLoaded', () => {
  const images = Array.from(document.querySelectorAll('img[style*="width:350px"]'));
  let currentIndex = 0;

  // Create lightbox container
  const lightbox = document.createElement('div');
  lightbox.id = 'lightbox';
  lightbox.style = `
    position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
    background: rgba(0,0,0,0.8);
    display: flex; align-items: center; justify-content: center;
    opacity: 0; pointer-events: none; transition: opacity 0.3s ease;
    z-index: 1000;
  `;
  document.body.appendChild(lightbox);

  // Create image element
  const lightboxImage = document.createElement('img');
  lightboxImage.style = 'max-width: 90%; max-height: 90%; border-radius: 5px; box-shadow: 0 0 10px white;';
  lightbox.appendChild(lightboxImage);

  // Create arrow elements
  const createArrow = (direction, symbol) => {
    const arrow = document.createElement('div');
    arrow.className = `lightbox-arrow ${direction}`;
    arrow.innerHTML = symbol;
    arrow.style = `
      position: absolute; top: 50%;
      ${direction === 'prev' ? 'left: 30px;' : 'right: 30px;'}
      font-size: 3rem; color: white;
      background: rgba(0,0,0,0.5); border-radius: 50%;
      padding: 10px; cursor: pointer; user-select: none;
      transform: translateY(-50%);
    `;
    lightbox.appendChild(arrow);
    return arrow;
  };

  const prevArrow = createArrow('prev', '&#10094;');
  const nextArrow = createArrow('next', '&#10095;');

  // Show image in lightbox
  function showImage(index) {
    if (index >= 0 && index < images.length) {
      currentIndex = index;
      lightboxImage.src = images[currentIndex].src;
      lightbox.style.opacity = '1';
      lightbox.style.pointerEvents = 'auto';
    }
  }

  // Close lightbox
  function closeLightbox() {
    lightbox.style.opacity = '0';
    lightbox.style.pointerEvents = 'none';
  }

  // Event listeners for gallery images
  images.forEach((img, index) => {
    img.style.cursor = 'pointer';
    img.addEventListener('click', () => showImage(index));
  });

  // Arrow click events
  prevArrow.addEventListener('click', (e) => {
    e.stopPropagation();
    showImage((currentIndex - 1 + images.length) % images.length);
  });

  nextArrow.addEventListener('click', (e) => {
    e.stopPropagation();
    showImage((currentIndex + 1) % images.length);
  });

  // Close on click outside image
  lightbox.addEventListener('click', (e) => {
    if (e.target === lightbox) closeLightbox();
  });

  // Keyboard navigation
  document.addEventListener('keydown', (e) => {
    if (lightbox.style.opacity === '1') {
      if (e.key === 'Escape') {
        closeLightbox();
      } else if (e.key === 'ArrowLeft') {
        showImage((currentIndex - 1 + images.length) % images.length);
      } else if (e.key === 'ArrowRight') {
        showImage((currentIndex + 1) % images.length);
      }
    }


