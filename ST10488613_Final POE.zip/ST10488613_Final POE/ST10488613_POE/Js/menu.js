document.addEventListener("DOMContentLoaded", function() {
    // Handle clicking on price tags
    const prices = document.querySelectorAll(".price");
    
    prices.forEach(function(priceTag) {
        priceTag.addEventListener("click", function() {
            const itemName = this.closest(".tattoo-item").querySelector(".tattoo-name")?.innerText || "this service";
            
            const confirmChoice = confirm(`Are you sure you want to choose ${itemName}?`);
            
            if (confirmChoice) {
                this.closest(".tattoo-item").style.backgroundColor = "#d1ffd1"; // light green
                setTimeout(() => {
                    this.closest(".tattoo-item").style.backgroundColor = "";
                }, 2000);
            }
        });
    });

    // Handle hover on treatment pics
    const treatmentPics = document.querySelectorAll(".treatment-pic");
    
    treatmentPics.forEach(function(pic) {
        pic.addEventListener("mouseenter", function() {
            this.style.border = "3px solid orange";
        });
        pic.addEventListener("mouseleave", function() {
            this.style.border = "";
        });
    });
});
