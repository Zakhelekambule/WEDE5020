document.addEventListener("DOMContentLoaded", function() {
    const solutionsButton = document.querySelector("button");

    solutionsButton.addEventListener("click", function(event) {
        event.preventDefault();
        const confirmNavigate = confirm("Are you sure you want to view solutions?");
        if (confirmNavigate) {
            window.location.href = "solutions.html";
        }
    });
});

