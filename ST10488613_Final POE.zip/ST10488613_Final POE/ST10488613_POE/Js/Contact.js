document.addEventListener("DOMContentLoaded", function() {
    // --- Solutions button confirmation ---
    const solutionsButton = document.querySelector("button");

    if (solutionsButton) {
        solutionsButton.addEventListener("click", function(event) {
            event.preventDefault();
            const confirmNavigate = confirm("If you click ok, we will receive your details. Do you want to view solutions?");
            if (confirmNavigate) {
                window.location.href = "solutions.html";
            }
        });
    }

    // --- Contact form validation (if form exists on the page) ---
    const form = document.querySelector("form");
    if (form) {
        form.addEventListener("submit", function(event) {
            event.preventDefault();

            const name = form.querySelector("input[name='name']").value.trim();
            const email = form.querySelector("input[name='email']").value.trim();
            const message = form.querySelector("textarea[name='message']").value.trim();

            if (!name || !email || !message) {
                alert("Please fill in all fields (Name, Email, and Message).");
                return;
            }

            if (!validateEmail(email)) {
                alert("Please enter a valid email address.");
                return;
            }

            alert("Thank you, " + name + "! Your message has been sent. We will get back to you soon.");

            form.reset();
        });
    }

    // Helper function to validate email
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email.toLowerCase());
    }
});
