// Get the hamburger icon and nav links container
const menuToggle = document.getElementById('menu-toggle');
const navLinks = document.querySelector('.nav-links');

// When the hamburger is clicked, toggle the 'open' class on nav-links
menuToggle.addEventListener('click', () => {
  navLinks.classList.toggle('open');
});
